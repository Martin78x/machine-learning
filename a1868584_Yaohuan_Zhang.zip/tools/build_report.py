"""Build the single English report from actual analysis.py outputs.
Run from project root: python tools/build_report.py --out outputs --report Report.pdf
"""
import argparse
import json
from pathlib import Path
from xml.sax.saxutils import escape
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
    TableStyle, Image, PageBreak, KeepTogether)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=Path('outputs'))
    ap.add_argument('--report',type=Path,default=Path('Report.pdf'))
    args=ap.parse_args(); out=args.out
    r=json.loads((out/'results.json').read_text()); t=r['training']; s=r['selection']; c=r['clustering']
    lr,svm=r['test_metrics']; m1,m2=s['models']
    # The detailed visual interpretation below describes the supplied dataset,
    # not an arbitrary replacement dataset or a different selected k.
    assert c['selected']['k']==2 and r['test_counts']=={'1':100,'7':900}
    assert s['selected_model']=='Logistic regression'
    normal=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
    bold=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
    if normal.exists() and bold.exists():
        pdfmetrics.registerFont(TTFont('Body',str(normal)))
        pdfmetrics.registerFont(TTFont('BodyBold',str(bold)))
        pdfmetrics.registerFontFamily('Body',normal='Body',bold='BodyBold',italic='Body',boldItalic='BodyBold')
        font,bfont='Body','BodyBold'
    else: font,bfont='Helvetica','Helvetica-Bold'
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='BodyText2',fontName=font,fontSize=9.2,leading=13.7,spaceAfter=8))
    styles.add(ParagraphStyle(name='Title2',fontName=bfont,fontSize=22,leading=28,textColor=colors.HexColor('#17134d'),spaceAfter=16))
    styles.add(ParagraphStyle(name='H1x',fontName=bfont,fontSize=15,leading=20,textColor=colors.HexColor('#17134d'),spaceAfter=12))
    styles.add(ParagraphStyle(name='H2x',fontName=bfont,fontSize=10.6,leading=15,spaceBefore=5,spaceAfter=6,textColor=colors.HexColor('#24547a')))
    styles.add(ParagraphStyle(name='Caption2',fontName=font,fontSize=8,leading=11,spaceAfter=10,textColor=colors.HexColor('#444444')))
    styles.add(ParagraphStyle(name='Cell2',fontName=font,fontSize=8,leading=11))
    story=[]; width=A4[0]-88
    def p(text): story.append(Paragraph(text,styles['BodyText2']))
    def h(text): story.append(Paragraph(text,styles['H1x']))
    def sub(text): story.append(Paragraph(text,styles['H2x']))
    def page(): story.append(PageBreak())
    def table(rows,widths=None):
        cells=[[Paragraph(escape(str(v)),styles['Cell2']) for v in row] for row in rows]
        tab=Table(cells,colWidths=widths or [width/len(rows[0])]*len(rows[0]),repeatRows=1,hAlign='LEFT')
        tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7ecf4')),
            ('TEXTCOLOR',(0,0),(-1,0),colors.HexColor('#17134d')),('VALIGN',(0,0),(-1,-1),'TOP'),
            ('GRID',(0,0),(-1,-1),.35,colors.HexColor('#cdd3df')),
            ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
        story.extend([tab,Spacer(1,10)])
    def fig(name,caption,maxh=240):
        image=Image(str(out/(name+'.png')))
        ratio=min(width/image.imageWidth,maxh/image.imageHeight)
        image.drawWidth=image.imageWidth*ratio; image.drawHeight=image.imageHeight*ratio
        story.append(image); story.append(Paragraph(caption,styles['Caption2']))
    def pct(v): return f'{v*100:.2f}%'

    story.append(Paragraph('MNIST 1 vs 7<br/>Classification and Clustering',styles['Title2']))
    p('<b>Yaohuan Zhang · a1868584</b><br/>Individual Written &amp; Coding Assignment')
    sub('Summary')
    p('This study uses only the supplied MNIST subset: 100 training images and 1,000 test images. '
      'A regularized linear logistic model is compared with a nonlinear radial-basis-function (RBF) SVM. '
      'All classifier tuning and model selection use the training set only. Both achieve 99.00% '
      'mean five-fold training cross-validation balanced accuracy. A predefined tie rule selects '
      'logistic regression as the primary classifier before any test arrays are read.')
    table([['Outcome','Observed result'],
        ['Primary locked model','Logistic regression, C=1, intercept=True'],
        ['Primary model: test performance',f'Accuracy {pct(lr["accuracy"])}; balanced accuracy {pct(lr["balanced_accuracy"])}; macro F1 {lr["macro_f1"]:.4f}'],
        ['Comparison model: test performance',f'RBF SVM: accuracy {pct(svm["accuracy"])}; balanced accuracy {pct(svm["balanced_accuracy"])}'],
        ['Digit-7 clustering',f'900 images; required k=100 completed; selected k=2, silhouette={c["selected"]["silhouette"]:.4f}']], [150,width-150])
    p('The test set has 100 ones and 900 sevens, unlike the balanced training set. Hence overall '
      'accuracy alone gives an incomplete picture. The linear model correctly recognizes all 100 '
      'ones but misclassifies 55 sevens. The SVM makes three fewer errors; this small post-hoc '
      'difference does not override the training-only selection rule.')
    sub('Scope and evidence')
    p('The four tasks are covered in order. Figures, metrics and tables are generated by '
      '<b>analysis.py</b>; the report builder reads its JSON and CSV outputs. No external images, '
      'pretrained models, augmentation or test-driven threshold adjustments are used. '
      'The separate clustering task uses test labels only to select digit-7 images after classification is finished.')
    p('Key limitations are the small training sample, uncertain representation of handwriting styles, '
      'selection variability and weak separation between the unsupervised clusters. A selected number '
      'of clusters is an operational choice under a specified criterion, not a proven natural taxonomy.')

    page(); h('Task 1 · Training data exploration (15%)')
    p('Each image is a 28 × 28 uint8 array, yielding 784 pixel features after flattening. '
      'Only train_data and train_targets are inspected during exploration. No missing or nonfinite '
      'training entries were found. All 100 training images are distinct.')
    table([['Statistic','Value','Implication for classification'],
        ['Class counts','50 digit 1; 50 digit 7','No majority-class advantage in training; use stratification.'],
        ['Feature/sample ratio','784 / 100 = 7.84','High dimensionality relative to sample size motivates regularization.'],
        ['Pixel range; mean; SD',f'0–255; {t["mean"]:.2f}; {t["std"]:.2f}','Scale consistently; raw magnitudes affect regularization and RBF distances.'],
        ['Zero pixels',pct(t['zero_fraction']),'Most image area is background; background pixels carry little within-sample signal.'],
        ['Constant pixel features',f'{t["constant_features"]} / 784','Many border features show no training variation; retaining them avoids extra feature-selection choices.'],
        ['Unique / nonfinite','100 unique; 0 nonfinite','No imputation or duplicate removal is needed.']], [115,115,width-230])
    fig('training_summary','Figure 1. Training class counts and class-mean images. Both classes are balanced. The mean seven has a top bar and diagonal stroke; the mean one concentrates intensity in a narrower central stem.',maxh=220)
    p('Digit 7 has mean intensity 29.53 versus 20.18 for digit 1. Nonzero pixels occupy 16.76% '
      'of seven images versus 11.27% of one images, on average. These differences suggest useful '
      'shape and ink-coverage cues; however, ink amount is not a reliable standalone rule because '
      'stroke width and handwriting vary. The full pixel arrangement is retained.')

    page(); h('Task 1 · Visual evidence and preprocessing')
    fig('training_examples','Figure 2. The first eight training examples of each digit, without cherry-picking by model performance. Stroke thickness, position and slant vary; the seven’s top bar offers an interpretable spatial cue.',maxh=190)
    fig('intensity_distributions','Figure 3. Left: distribution of mean intensity per training image. Right: nonzero-pixel intensity density. Overlapping intensity distributions show why scalar brightness alone cannot capture all class differences.',maxh=190)
    sub('Preprocessing decisions')
    p('<b>Reshape and scale:</b> images are flattened to 784-dimensional vectors and divided by '
      '255, giving inputs in [0,1]. The transformation has no fitted parameters. It is included '
      'inside each classifier pipeline for consistent application to training folds and held-out data. '
      'For the RBF SVM it gives the gamma search a meaningful distance scale; for logistic '
      'regression it makes the chosen regularization range interpretable.')
    p('<b>Keep spatial information:</b> no binarization, image centering, deskewing, PCA feature '
      'reduction or feature selection is applied to classification. With only 100 training images, '
      'extra estimated preprocessing steps add tuning uncertainty. Retaining 784 features also '
      'keeps the model comparison under the same representation. A constant training column '
      'is retained; regularization controls its contribution.')
    p('<b>Image polarity:</b> the supplied arrays have low background values and high stroke '
      'values, visible with Matplotlib’s gray colormap (black at 0, white at 255). This differs '
      'from the illustrative white-background wording in the brief. The actual values are '
      'preserved, with no unnecessary inversion.')

    page(); h('Task 2 · Classification system (25%)')
    sub('Why regularized logistic regression?')
    p('The first classifier is binary logistic regression with L2 regularization. Its decision '
      'function is linear in the flattened pixels: p(y=7 | x) = sigmoid(wᵀx + b). '
      'It learns a spatial contrast between the training classes rather than a threshold on '
      'brightness alone. The class-mean images show plausible linear cues: the seven’s upper '
      'horizontal bar and diagonal stem differ from the one’s central vertical stroke.')
    p('There are more pixel features than examples, so a highly flexible unregularized model '
      'could fit training idiosyncrasies. L2 shrinkage penalizes large coefficients, making a '
      'regularized linear model an appropriate low-variance baseline. The inverse regularization '
      'parameter C is selected by training-only CV; smaller C imposes stronger shrinkage. '
      'The intercept is also varied because background-dominated positive pixel values need not '
      'place the optimal decision boundary through the origin. liblinear, max_iter=5000 and '
      'random_state=42 are fixed implementation settings.')
    sub('Metrics chosen before test inspection')
    table([['Metric','Definition and purpose'],
        ['Balanced accuracy (primary)','(Recall for digit 1 + recall for digit 7) / 2. Gives equal importance to both classes even if prevalence changes.'],
        ['Accuracy','Fraction correctly classified. Intuitive but prevalence-sensitive; report alongside balanced accuracy.'],
        ['Macro F1','Arithmetic mean of class-specific F1 scores. Exposes precision/recall problems for either class.'],
        ['Precision, recall and F1 for digit 7','Treat 7 as the positive class. Precision measures false-positive contamination; recall measures missed sevens.'],
        ['ROC AUC','Ranking quality using decision_function scores, with 7 positive. It is threshold-independent, not a calibration metric.'],
        ['Confusion matrix','Rows are true labels [1,7]; columns are predicted labels [1,7]. Shows the error direction.']], [130,width-130])
    p('During the five-fold search, accuracy, macro F1 and ROC AUC are recorded as secondary '
      'metrics. Only balanced accuracy is used to choose hyperparameters. No class weights, '
      'probability calibration or decision-threshold optimization are introduced. Both models '
      'use their standard decision boundary at decision score zero.')
    sub('Training implementation')
    p('model_specs() constructs a pipeline containing the fixed scaler and classifier. '
      'classifier_search() passes only training pixels and labels into GridSearchCV. '
      'After parameter selection, GridSearchCV refits the best pipeline on all 100 training '
      'examples. The best logistic model uses <b>C=1, fit_intercept=True</b>.')

    page(); h('Task 3 · Comparison and tuning design (35%)')
    sub('Second classifier: nonlinear RBF SVM')
    p('The RBF kernel is K(x,z) = exp(−gamma × ||x−z||²). Unlike the global linear boundary '
      'of logistic regression, it can separate classes using nonlinear similarities between '
      'handwriting images. C trades margin width against training errors; gamma controls '
      'locality. Very large gamma can memorize individual pixel patterns, whereas very small '
      'gamma may yield insufficiently distinct similarities. This flexibility makes SVM a '
      'meaningful comparison under the same small-sample constraints.')
    table([['Model','Search space','Candidates'],
        ['Logistic regression','C ∈ {0.001, 0.01, 0.1, 1, 10, 100}; intercept ∈ {True, False}','12'],
        ['RBF SVM','C ∈ {0.01, 0.1, 1, 10, 100}; gamma ∈ {0.0001, 0.001, 0.01, 0.1, 1, scale}','30']], [105,width-165,60])
    p('The log-spaced ranges span substantial changes in regularization and kernel locality. '
      'For SVC, gamma="scale" is computed from the current training fold as '
      '1 / (number of features × variance of the scaled fold), avoiding held-out statistics.')
    sub('Validation, selection and uncertainty')
    p('A shuffled, stratified five-fold splitter (seed 42) creates identical splits for both '
      'models. Each split has 80 training images and 20 validation images, with both classes '
      'balanced. Every candidate is fit five times: 210 fits in the main search plus final refits. '
      'The highest mean balanced accuracy wins. Within-model exact ties use the first candidate '
      'in the declared grid order (smaller C first; intercept=True before False). Across-model '
      'exact ties prefer the simpler linear model. These rules are fixed before test access.')
    table([['Training-only result','Logistic regression','RBF SVM'],
        ['Best parameters','C=1; intercept=True','C=1; gamma=0.01'],
        ['Mean CV balanced accuracy ± SD',f'{pct(m1["cv_balanced_accuracy"])} ± {pct(m1["cv_sd"])}',f'{pct(m2["cv_balanced_accuracy"])} ± {pct(m2["cv_sd"])}'],
        ['CV macro F1 / ROC AUC',f'{m1["cv_macro_f1"]:.4f} / {m1["cv_auc"]:.4f}',f'{m2["cv_macro_f1"]:.4f} / {m2["cv_auc"]:.4f}'],
        ['Mean training-fold balanced accuracy','100.00%','100.00%'],
        ['Nested CV balanced accuracy ± SD',f'{pct(m1["nested_cv_balanced_accuracy"])} ± {pct(m1["nested_cv_sd"])}',f'{pct(m2["nested_cv_balanced_accuracy"])} ± {pct(m2["nested_cv_sd"])}']], [185,(width-185)/2,(width-185)/2])
    p('The additional nested check uses five outer folds with a fresh four-fold search inside '
      'each outer-training subset. It assesses the tuning procedure with outer observations '
      'excluded from all inner searches. It is supplementary and does not change the predefined '
      'main-search selection rule. Fold SD describes variation, not a confidence interval: '
      'folds share training data and n=100 is small. The non-nested winning score can be optimistic.')

    page(); h('Task 3 · Hyperparameter effects')
    fig('logistic_tuning','Figure 4. Logistic regression: mean five-fold balanced accuracy with fold SD bars. Intercept settings overlap. Larger C reaches a validation plateau rather than demonstrating continuing improvement.',maxh=230)
    p('At C=0.001 logistic regression obtains 97% validation balanced accuracy, drops to 96% '
      'at C=0.01, then increases to 98% at C=0.1 and 99% for C≥1. This is not a strictly '
      'monotonic curve; a small sample and discrete validation errors produce fluctuations. '
      'Both intercept settings have identical aggregate scores across the tested range. '
      'C=1 is selected as the first point on the best plateau; there is no validation evidence '
      'for weakening regularization further.')
    fig('svm_tuning','Figure 5. Full RBF SVM search. Both C and gamma matter, and several settings tie at 99%. Values are fractions, so 0.99 means 99% balanced accuracy.',maxh=230)
    p('SVM performs poorly with gamma=1 (58–65% validation balanced accuracy), despite 100% '
      'mean training accuracy. Highly local kernels overfit these 100 images. Gamma=0.01 '
      'with C≥1 reaches 99%; gamma=0.001 requires C≥10 to reach the same score. '
      'These interactions show why tuning only C would be incomplete. C=1, gamma=0.01 '
      'is the first tied-best setting. Equal best validation performance provides no evidence '
      'that nonlinear capacity is necessary on this training sample.')

    page(); h('Task 3 · Locked final test evaluation')
    p('After both model searches finish, selection_locked_before_test.json is saved. '
      'Only then are test_data and test_targets read. Both fixed models are evaluated for '
      'comparison; the primary model remains logistic regression. Test class counts are '
      '100 ones and 900 sevens. An always-seven baseline has 90% accuracy, 50% balanced '
      'accuracy and macro F1≈0.4737. The primary classifier improves on all three.')
    table([['Final test metric','Logistic regression','RBF SVM'],
        ['Accuracy',pct(lr['accuracy']),pct(svm['accuracy'])],
        ['Balanced accuracy',pct(lr['balanced_accuracy']),pct(svm['balanced_accuracy'])],
        ['Macro F1',f'{lr["macro_f1"]:.4f}',f'{svm["macro_f1"]:.4f}'],
        ['Precision for digit 7',pct(lr['precision_7']),pct(svm['precision_7'])],
        ['Recall for digit 7',pct(lr['recall_7']),pct(svm['recall_7'])],
        ['F1 for digit 7',f'{lr["f1_7"]:.4f}',f'{svm["f1_7"]:.4f}'],
        ['ROC AUC',f'{lr["roc_auc"]:.4f}',f'{svm["roc_auc"]:.4f}'],
        ['Errors / 1,000',lr['errors'],svm['errors']]], [185,(width-185)/2,(width-185)/2])
    fig('test_confusion_matrices','Figure 6. Both models classify every digit 1 correctly. Their errors are exclusively sevens predicted as ones: 55 for logistic regression and 52 for SVM.',maxh=235)
    p('For logistic regression, precision for digit 1 is 100/155=64.52% even though recall '
      'for digit 1 is 100%. Its class-1 F1 is 0.7843, while class-7 F1 is 0.9685; their '
      'unweighted mean is macro F1=0.8764. Thus a high positive-class F1 does not imply '
      'both predicted groups are equally pure. Balanced accuracy measures equal-class recall; '
      'macro F1 additionally exposes misclassified sevens contaminating predicted ones.')

    page(); h('Task 3 · Interpretation and limitations')
    fig('test_errors','Figure 7. The first ten test errors of the preselected logistic model, in original test-index order. These are diagnostic examples only and are not used to alter the model or threshold.',maxh=270)
    p('Several errors have crossbars, narrow stems, or shapes unlike the typical training '
      'seven. Such features can resemble the central stroke of a one under a fixed pixel '
      'representation. This is a plausible visual explanation, not a quantified causal claim; '
      'the images displayed are the first errors, not a representative random sample of all errors.')
    p('The RBF SVM improves accuracy by 0.3 percentage points and balanced accuracy by '
      'about 0.17 percentage points on the test set. This corresponds to only three fewer '
      'errors and does not establish statistically reliable superiority. The linear model '
      'remains the declared primary model because the selection criterion was training CV. '
      'Switching models after this comparison would use the test set for model selection.')
    low,high=lr['accuracy_wilson_95']
    p(f'The primary model’s 95% Wilson accuracy interval is [{pct(low)}, {pct(high)}]. '
      'This is an approximate binomial summary under independent sampling; it excludes '
      'training-set and model-selection variability and cannot be read as a guarantee for '
      'future handwriting populations. The fixed sample’s origin and class imbalance '
      'also limit generalization claims.')
    p('The balanced training distribution and 10:90 test prevalence differ markedly. '
      'Accuracy, precision and F1 depend on this prevalence; balanced accuracy and ROC AUC '
      'are less directly affected by the class prior, though changes in within-class '
      'difficulty can still affect them. The drop from 99% CV to 96.94% test balanced '
      'accuracy may reflect small training coverage, selection optimism and sampling '
      'differences. It cannot be attributed to prior shift alone.')
    p(f'A post-selection audit finds {r["exact_train_test_overlap"]} exact train–test image overlaps. '
      'No images are removed or replaced. The audit uses byte equality and cannot detect '
      'related writers or near-duplicates. No new classifier design decisions follow this audit.')

    page(); h('Task 4 · Digit-7 clustering (25%)')
    p('After classification is complete, the true test labels select the 900 images of '
      'digit 7. This label-based filtering is explicitly required for Task 4. No classifier '
      'predictions are used to filter the data, so classification errors are not silently excluded. '
      'The clustering results never feed back into classifier fitting, tuning or selection.')
    sub('Method and number of clusters')
    p('Flattened pixels are divided by 255 and clustered directly in 784 dimensions with '
      'Euclidean K-means (Lloyd algorithm, k-means++ initialization, 20 restarts, seed 42). '
      'The objective is within-cluster sum of squared distances (SSE). First k=100 is fit '
      'as required; all 100 centroids are shown in Appendix A. This partitions the data '
      'into many small style prototypes rather than necessarily meaningful categories.')
    p('The predefined candidate set is k=2,3,…,30,40,50,60,70,80,90,99. The largest mean '
      'silhouette across all 900 images selects k; an exact tie selects the smaller k. '
      'For each image, silhouette=(b−a)/max(a,b), where a is mean within-cluster distance '
      'and b is the nearest alternative cluster’s mean distance. Singleton scores are zero '
      'under the library convention. This evaluates compactness and separation, unlike '
      'SSE alone, which generally falls as k increases. Davies–Bouldin is a secondary '
      'diagnostic and is not an additional selection criterion.')
    frame=pd.read_csv(out/'clustering_candidates.csv').set_index('k')
    rows=[['k','SSE','Silhouette','Davies–Bouldin']]
    for k in [2,3,4,10,30,99]:
        v=frame.loc[k]; rows.append([k,f'{v.inertia:.2f}',f'{v.silhouette:.4f}',f'{v.davies_bouldin:.4f}'])
    rows.append([100,f'{c["initial_100_inertia"]:.2f}',f'{c["initial_100_silhouette"]:.4f}','Initial fit; not a candidate'])
    table(rows,[50,120,110,width-280])
    fig('cluster_selection','Figure 8. SSE, mean silhouette and Davies–Bouldin over the candidate range. The dashed line marks the predefined silhouette winner, k=2. SSE reduction alone would reward increasingly fine partitions.',maxh=180)
    p('The silhouette maximum is 0.1217 at k=2, ahead of 0.1080 at k=3. At k=100 it is '
      f'{c["initial_100_silhouette"]:.4f}, with {c["initial_100_singletons"]} singleton clusters. '
      'The smaller solution gives a parsimonious coarse summary; its low absolute '
      'silhouette still indicates considerable overlap. This is the best tested solution '
      'under the chosen metric, not proof of an optimal number across all representations '
      'or every integer below 100.')

    page(); h('Task 4 · Interpretation of every selected cluster')
    fig('cluster_members','Figure 9. Each row shows one selected cluster: its mean image followed by six closest actual members. Members are chosen within their assigned cluster by Euclidean distance to its center, not by visual preference.',maxh=245)
    rows=[['Cluster','Size','Share','Mean intensity','Top-minus-bottom x']]
    for profile in c['profiles']:
        rows.append([profile['cluster'],profile['n'],f'{profile["percent"]:.2f}%',f'{profile["mean_intensity"]:.4f}',f'{profile["top_minus_bottom_x"]:+.2f} pixels'])
    table(rows,[55,60,70,110,width-295])
    p('<b>Cluster 0 (406 images, 45.11%):</b> the mean and nearest members show a '
      'pronounced diagonal stem extending down-left from the upper-right corner. The '
      'horizontal top bar is clear. The nearest real representative is original test index '
      '755. The top-band ink center lies 2.51 pixels to the right of the bottom-band ink '
      'center, consistent with the diagonal pattern. Mean intensity is 0.1131, slightly '
      'higher than in cluster 1; brightness and shape are both encoded by pixel distance.')
    p('<b>Cluster 1 (494 images, 54.89%):</b> the lower stem is more upright and remains '
      'farther right relative to the broad, left-extending top bar. Its closest representative '
      'is test index 382. The top-minus-bottom horizontal displacement is −2.48 pixels, '
      'opposite in sign to cluster 0. Mean intensity is 0.1066. Within-cluster stroke '
      'thickness and curvature still vary, so the cluster is not a single rigid template.')
    p('To quantify the visual interpretation, the horizontal ink center is computed from '
      'each mean image separately in rows 0–11 (top) and 16–27 (bottom), with columns '
      'indexed 0–27 increasing to the right. Their difference describes a coarse '
      'shape displacement; it is affected by the top bar and should not be interpreted '
      'as an exact fitted stem angle. Cluster IDs are arbitrary.')
    p('The overall ink centers for both clusters are close to (14,14), suggesting the '
      'split is not merely a large global image translation. These measurements '
      'support the visual account but do not establish writer identity, language-specific '
      'style or a distinct crossbar category.')

    page(); h('Task 4 · Stability, projection and synthesis')
    fig('cluster_pca','Figure 10. Two-dimensional PCA display of the 784-dimensional digit-7 data. Black crosses indicate projected cluster centers. Apparent 2D separation is not the criterion used to select k.',maxh=285)
    ari=[v['adjusted_rand_vs_selected'] for v in c['seed_stability']]
    p(f'The first two PCs explain {sum(c["pca_explained_variance"])*100:.2f}% of total variance '
      f'({c["pca_explained_variance"][0]*100:.2f}% and {c["pca_explained_variance"][1]*100:.2f}%). '
      'Most information is outside this projection; it cannot prove high-dimensional '
      'cluster separation. PCA is fit only for this post-hoc display, never used in the classifiers '
      'or the K-means feature space.')
    p(f'For the selected k=2, five additional fits with seeds 0–4 and 20 restarts give '
      f'adjusted Rand agreement {min(ari):.4f}–{max(ari):.4f} against the seed-42 partition. '
      'This indicates low initialization sensitivity for this fixed data and k. '
      'It is not evidence of stability across new samples, and it does not assess whether '
      'the entire k-selection process would choose two on a different dataset.')
    sub('Limitations and final interpretation')
    p('Euclidean pixel distances are sensitive to slant, translation and stroke intensity. '
      'K-means assumes compact groups around means and may partition a continuous style '
      'spectrum. The low silhouette and overlapping projection favor cautious interpretation: '
      'two useful coarse prototypes, rather than two well-separated natural subpopulations. '
      'The candidate grid becomes coarser above 30, and the preferred k can change under '
      'different features, metrics or a denser search.')
    p('Together, the experiments support a regularized linear classifier as a strong '
      'small-data baseline. The nonlinear model is competitive but has no main-CV advantage. '
      'The clustering reveals interpretable variation among sevens, which helps describe '
      'the data without being used to optimize the classifier on the test set. More training '
      'examples and independently evaluated shape-aware preprocessing are plausible future '
      'directions; they are not claimed as tested improvements here.')

    page(); h('Appendix A · Required 100-cluster visualization')
    fig('centers_100','Figure 11. All 100 K-means centers from the required initial fit. Each caption gives the cluster ID and membership count. These are mean images, not necessarily observed samples; small clusters can preserve atypical shapes or isolated examples.',maxh=620)
    p('The 100-cluster solution has average cluster size 9.0. Its lower SSE is expected from '
      'higher capacity and does not by itself justify the number of clusters. The primary '
      'interpretation in Task 4 concerns every cluster of the selected two-cluster solution.')

    page(); h('Reproducibility and references')
    sub('Reproducing the analysis')
    p('Use Python 3.12, install requirements-lock.txt, then run from the extracted project root:<br/>'
      '<font face="Courier" size="8">python analysis.py --data /path/to/course_file.npz --out outputs<br/>'
      'python tools/build_report.py --out outputs --report Report.pdf</font>')
    p('The filename can differ from the original download; --data sets the path. '
      'Expected NPZ keys are train_data, train_targets, test_data, test_targets. '
      'The script validates the documented dimensions and labels. It uses CPU execution, '
      'two numerical-library threads, one search worker and seed 42. All direct '
      'dependencies are pinned; the full validated dependency set is in requirements-lock.txt. '
      'Small floating-point differences may occur on other library versions or platforms.')
    table([['Output','Purpose'],
        ['results.json','Statistics, selected settings, final metrics, clustering profiles and data checksum.'],
        ['*_cv_results.csv; nested_cv_results.csv','All candidate/fold scores; supplementary nested-validation evidence.'],
        ['selection_locked_before_test.json','Written before the first test-array access. Records the fixed training-only rule and selected models.'],
        ['test_predictions.csv; test_metrics.csv','Test labels, fixed predictions and final metric values.'],
        ['clustering_candidates.csv; cluster_seed_stability.csv','All k-selection scores and fixed-k initialization-sensitivity checks.'],
        ['selected_cluster_profiles.csv; cluster_assignments.csv','Every selected cluster’s statistics and original test member indices.'],
        ['cluster_centers.npz; PNG figures','Initial and selected centers; publication figures generated from this run.']], [195,width-195])
    p('<b>Dataset SHA-256:</b><br/><font size="7">'+r['dataset_sha256']+'</font>')
    p('Validated core versions: '+', '.join(f'{escape(k)} {escape(v)}' for k,v in r['versions'].items())+'. '
      'The course dataset is omitted from the submission as requested. No result in this '
      'report requires access to an external service after dependencies are installed.')
    sub('References')
    for ref in [
        'LeCun, Y., Bottou, L., Bengio, Y., & Haffner, P. (1998). Gradient-based learning applied to document recognition. Proceedings of the IEEE, 86(11), 2278–2324. doi:10.1109/5.726791.',
        'Pedregosa, F., et al. (2011). Scikit-learn: Machine learning in Python. Journal of Machine Learning Research, 12, 2825–2830.',
        'Rousseeuw, P. J. (1987). Silhouettes: A graphical aid to the interpretation and validation of cluster analysis. Journal of Computational and Applied Mathematics, 20, 53–65. doi:10.1016/0377-0427(87)90125-7.',
        'Scikit-learn documentation: LogisticRegression, SVC, GridSearchCV, KMeans, silhouette_score and balanced_accuracy_score. https://scikit-learn.org/stable/ (API reference).',
        'Course materials: Assignment description screenshots; Assignment-rubric.xlsx; supplied mnist_1_7_subsets-1.npz.'
    ]: p(escape(ref))
    def footer(canvas,doc):
        canvas.saveState(); canvas.setFont(font,8); canvas.setFillColor(colors.HexColor('#555555'))
        canvas.drawString(44,27,'a1868584 · Yaohuan Zhang | MNIST 1 vs 7')
        canvas.drawRightString(A4[0]-44,27,f'{doc.page}')
        canvas.restoreState()
    args.report.parent.mkdir(parents=True,exist_ok=True)
    doc=SimpleDocTemplate(str(args.report),pagesize=A4,rightMargin=44,leftMargin=44,
        topMargin=38,bottomMargin=45,title='MNIST 1 vs 7 — Classification and Clustering',author='Yaohuan Zhang')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print('Report written:',args.report)


if __name__=='__main__': main()
