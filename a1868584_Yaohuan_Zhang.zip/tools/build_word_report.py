"""Create an editable Word report from the same text, tables and figures as the PDF.
Requires python-docx in addition to requirements.txt.
Run from the project root: python tools/build_word_report.py
"""
import sys
import re
from html import unescape
from pathlib import Path
from unittest.mock import patch
import importlib.util
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from reportlab.platypus import Paragraph, Table, Image, PageBreak, KeepTogether

root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('report_builder',root/'tools/build_report.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
story=[]
def capture(self, flowables, **kwargs):
    story.extend(flowables)
with patch.object(module.SimpleDocTemplate,'build',capture):
    with patch.object(sys,'argv',['build_report.py','--out',str(root/'outputs'),'--report',str(root/'Report.pdf')]):
        module.main()

doc=Document(); sec=doc.sections[0]
sec.page_width=Inches(8.2677); sec.page_height=Inches(11.6929)
sec.top_margin=Inches(.55); sec.bottom_margin=Inches(.6)
sec.left_margin=sec.right_margin=Inches(.61)
normal=doc.styles['Normal']; normal.font.name='Calibri'; normal.font.size=Pt(10)
normal.paragraph_format.space_after=Pt(7)
normal.paragraph_format.line_spacing=1.08
for style in ['Title','Heading 1','Heading 2']:
    doc.styles[style].font.color.rgb=RGBColor.from_string('17134D')
footer=sec.footer.paragraphs[0]
footer.add_run('a1868584 · Yaohuan Zhang | MNIST 1 vs 7     ')
field=OxmlElement('w:fldSimple'); field.set(qn('w:instr'),'PAGE');footer._p.append(field)
footer.style='Caption'

def text(value):
    if isinstance(value,Paragraph):
        return unescape(re.sub(r'<[^>]+>', '', re.sub(r'<br\s*/?>', '\n', value.text)))
    return str(value)

def add(item):
    if isinstance(item,Paragraph):
        name=item.style.name
        style={'Title2':'Title','H1x':'Heading 1','H2x':'Heading 2','Caption2':'Caption'}.get(name,'Normal')
        p=doc.add_paragraph(text(item),style)
        if name=='Caption2': p.paragraph_format.keep_with_next=False
    elif isinstance(item,Table):
        values=item._cellvalues
        t=doc.add_table(rows=len(values),cols=len(values[0])); t.style='Light Shading Accent 1'
        for i,row in enumerate(values):
            for j,v in enumerate(row):
                cell=t.cell(i,j)
                cell.text='\n'.join(text(x) for x in v) if isinstance(v,(tuple,list)) else text(v)
                for p in cell.paragraphs:
                    p.paragraph_format.space_after=Pt(3)
                    for run in p.runs: run.font.size=Pt(9)
                if i==0:
                    for run in cell.paragraphs[0].runs: run.bold=True
        trpr=t.rows[0]._tr.get_or_add_trPr(); repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
        doc.add_paragraph().paragraph_format.space_after=Pt(1)
    elif isinstance(item,Image):
        doc.add_picture(item.filename,width=Inches(item.drawWidth/72),height=Inches(item.drawHeight/72))
        doc.paragraphs[-1].alignment=1
    elif isinstance(item,PageBreak): doc.add_page_break()
    elif isinstance(item,KeepTogether):
        for child in item._content: add(child)

for item in story: add(item)
doc.core_properties.author='Yaohuan Zhang'
doc.core_properties.title='MNIST 1 vs 7 — Classification and Clustering'
path=root/'Report.docx';doc.save(path)
print('Editable Word report written:',path)
