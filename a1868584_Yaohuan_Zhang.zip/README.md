# MNIST digits 1 and 7: classification and clustering

Student: **Yaohuan Zhang** · ID: **a1868584**

## 运行方法 / Run

Use Python 3.12. From the extracted project directory:

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell instead: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python analysis.py --data /path/to/mnist_1_7_subsets-1.npz --out outputs
python tools/build_word_report.py
```

The NPZ filename may vary: pass the actual course-provided file using `--data`.
No dataset download occurs. The dataset is intentionally excluded from submission.
On this cloud machine the prepared interpreter is `/workspace/.venvs/mnist/bin/python`;
the dataset is at `data/mnist_1_7_subsets.npz`.

## 文件说明

- `analysis.py`: 模块化实验代码，包含训练集探索、两个分类器的交叉验证调参、最终测试评估和数字 7 的聚类。
- `Report.docx`: 可编辑的英文实验报告，包含四项任务的结果、图表、方法解释和局限。
- `tools/build_word_report.py`: 重新生成 Word 报告；`tools/build_report.py`: 共享报告内容和可选 PDF 生成器。
- `requirements.txt`: 直接依赖版本；`requirements-lock.txt`: 实际验证环境的完整依赖版本。
- `outputs/`（运行后生成）: CSV 参数搜索表、JSON 实验记录、预测、簇成员、中心及 PNG 图表。

Use `python -m pip install -r requirements-lock.txt` instead of `requirements.txt` to
reproduce all validated transitive dependency versions on a compatible platform.

## Experimental protocol

1. Explore only the 100 training images. Convert 28×28 to 784 features and divide by 255.
2. Search logistic regression (`C`, intercept) and RBF SVM (`C`, gamma) with identical
   stratified five-fold splits, seed 42. Balanced accuracy is the primary metric.
3. Use nested five-outer/four-inner-fold CV as a supplementary training-only check.
4. Select the model by the full-training five-fold search score; exact ties prefer
   logistic regression. Persist `selection_locked_before_test.json` before opening test arrays.
5. Evaluate both locked models on the 1,000 test examples. No subsequent retuning.
6. Independently cluster only the test images with true label 7: K-means with 100
   clusters, then a prespecified search below 100 using mean silhouette. PCA is only
   a display projection, not a feature transform for classification or clustering.

The default run uses at most two BLAS/OpenMP threads and one GridSearchCV worker.
All algorithms are CPU-based. No external credentials or running web services are needed.

## 提交前

提交包 `a1868584_Yaohuan Zhang.zip` 已按提供的姓名和学号命名。先阅读报告并运行代码，
确认能够解释模型选择、交叉验证和聚类结果，并按课程规定说明所使用的辅助工具。
ZIP 中不包含课程数据集；不要将课程数据文件加入提交包。
