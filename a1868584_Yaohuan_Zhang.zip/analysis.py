"""Reproducible MNIST 1-vs-7 classification and post-hoc test-digit-7 clustering.

Usage: python analysis.py --data data/mnist_1_7_subsets.npz --out outputs
Model selection never reads test arrays. No downloads, augmentation or extra data.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR', '/tmp/mnist-matplotlib')
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/mnist-cache')
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from sklearn.base import clone
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, precision_score,
    recall_score, f1_score, roc_auc_score, confusion_matrix, ConfusionMatrixDisplay,
    silhouette_score, davies_bouldin_score, adjusted_rand_score)
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits

SEED = 42
CANDIDATE_K = list(range(2, 31)) + [40, 50, 60, 70, 80, 90, 99]


def scale_pixels(x):
    """Fixed /255 scaling requires no fitted statistics and cannot leak test data."""
    return np.asarray(x, dtype=np.float64) / 255.0


def savefig(out, name):
    plt.savefig(out / f'{name}.png', dpi=170, bbox_inches='tight')
    plt.close()


def inspect_training(images, y, out):
    """Task 1: inspect only training images and labels."""
    assert images.shape == (100, 28, 28) and y.shape == (100,)
    assert np.isfinite(images).all() and set(np.unique(y)) == {1, 7}
    x = images.reshape(len(images), -1)
    stats = dict(shape=list(images.shape), dtype=str(images.dtype),
        class_counts={str(c): int((y == c).sum()) for c in [1, 7]},
        minimum=int(x.min()), maximum=int(x.max()), mean=float(x.mean()),
        std=float(x.std()), zero_fraction=float((x == 0).mean()),
        constant_features=int((np.ptp(x, axis=0) == 0).sum()),
        unique_images=int(len(np.unique(x, axis=0))),
        duplicate_images=int(len(x)-len(np.unique(x, axis=0))),
        nonfinite=int((~np.isfinite(x)).sum()))
    rows = []
    for c in [1, 7]:
        a = x[y == c]
        rows.append(dict(digit=c, count=len(a), mean_intensity=float(a.mean()),
            intensity_std=float(a.std()), active_pixel_fraction=float((a>0).mean()),
            mean_total_intensity=float(a.sum(axis=1).mean()),
            std_total_intensity=float(a.sum(axis=1).std())))
    stats['by_class'] = rows
    pd.DataFrame(rows).to_csv(out/'training_class_statistics.csv', index=False)
    fig, axes = plt.subplots(2, 8, figsize=(11, 3.7))
    for r, c in enumerate([1, 7]):
        inds = np.flatnonzero(y == c)[:8]
        for ax, idx in zip(axes[r], inds):
            ax.imshow(images[idx], cmap='gray', vmin=0, vmax=255)
            ax.set_title(f'Digit {c} | train {idx}', fontsize=8); ax.axis('off')
    fig.suptitle('Training samples: variation in slant, stroke width and position')
    fig.tight_layout(); savefig(out, 'training_examples')
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.4))
    axes[0].bar(['1', '7'], [(y==1).sum(), (y==7).sum()], color=['#3178ad','#e28436'])
    axes[0].set(xlabel='Digit', ylabel='Training images', title='Balanced classes')
    for i,c in enumerate([1,7]): axes[0].text(i, (y==c).sum()+.5, str((y==c).sum()), ha='center')
    for ax,c in zip(axes[1:],[1,7]):
        im=ax.imshow(images[y==c].mean(axis=0), cmap='gray',vmin=0,vmax=255)
        ax.set_title(f'Digit {c}: mean image'); ax.set(xlabel='Pixel column',ylabel='Pixel row')
    fig.colorbar(im, ax=list(axes[1:]), label='Mean pixel intensity (0–255)', shrink=.8)
    savefig(out, 'training_summary')
    fig, axes = plt.subplots(1,2,figsize=(10,3.6))
    for c,color in [(1,'#3178ad'),(7,'#e28436')]:
        a=images[y==c]
        axes[0].hist(a.mean(axis=(1,2)), bins=np.linspace(0,100,21),alpha=.6,label=f'Digit {c}',color=color)
        axes[1].hist(a[a>0],bins=20,alpha=.5,density=True,label=f'Digit {c}',color=color)
    axes[0].set(xlabel='Mean image intensity',ylabel='Number of images',title='Image-level ink distribution')
    axes[1].set(xlabel='Nonzero pixel intensity',ylabel='Density',title='Stroke pixel intensities (zeros excluded)')
    for ax in axes: ax.legend()
    fig.tight_layout(); savefig(out,'intensity_distributions')
    return x,stats


def model_specs():
    """Freeze both search spaces and tie rules before opening the test arrays.

    With n=100 and p=784, regularization controls the linear model's capacity;
    the RBF model tests whether nonlinear similarity adds useful flexibility.
    """
    lr=Pipeline([('scale',FunctionTransformer(scale_pixels)),
        ('model',LogisticRegression(solver='liblinear', max_iter=5000, random_state=SEED))])
    svm=Pipeline([('scale',FunctionTransformer(scale_pixels)),
        ('model',SVC(kernel='rbf'))])
    return {
        'Logistic regression': (lr, {'model__C':[.001,.01,.1,1,10,100],
                                    'model__fit_intercept':[True,False]}),
        'RBF SVM': (svm, {'model__C':[.01,.1,1,10,100],
                         'model__gamma':[.0001,.001,.01,.1,1,'scale']})}


def classifier_search(x,y,out):
    """Tasks 2–3. Identical stratified splits; all fitting is training-only.

    Primary selection metric: mean balanced accuracy; exact cross-model ties
    favor the linear model. Nested CV estimates the whole tuning procedure,
    but is not an extra search criterion. Fold SD is not a confidence interval.
    """
    scoring={'balanced_accuracy':'balanced_accuracy', 'accuracy':'accuracy',
             'f1_macro':'f1_macro', 'roc_auc':'roc_auc'}
    cv=list(StratifiedKFold(5,shuffle=True,random_state=SEED).split(x,y))
    specs=model_specs(); fitted={}; summaries=[]; nested_rows=[]
    for name,(pipe,grid) in specs.items():
        slug='logistic' if name.startswith('Logistic') else 'svm'
        search=GridSearchCV(pipe,grid,scoring=scoring,refit='balanced_accuracy',cv=cv,
                            n_jobs=1,return_train_score=True,error_score='raise')
        search.fit(x,y)
        frame=pd.DataFrame(search.cv_results_)
        frame.to_csv(out/f'{slug}_cv_results.csv',index=False)
        params={k.replace('model__',''):v for k,v in search.best_params_.items()}
        row=dict(model=name, params=params, cv_balanced_accuracy=float(search.best_score_),
            cv_sd=float(frame.iloc[search.best_index_]['std_test_balanced_accuracy']),
            cv_accuracy=float(frame.iloc[search.best_index_]['mean_test_accuracy']),
            cv_macro_f1=float(frame.iloc[search.best_index_]['mean_test_f1_macro']),
            cv_auc=float(frame.iloc[search.best_index_]['mean_test_roc_auc']),
            train_balanced_accuracy=float(frame.iloc[search.best_index_]['mean_train_balanced_accuracy']),
            candidates=len(frame))
        # Outer held-out samples are excluded from each inner search entirely.
        for fold,(train,valid) in enumerate(cv):
            inner=StratifiedKFold(4,shuffle=True,random_state=SEED+fold+1)
            nested=GridSearchCV(clone(pipe),grid,scoring='balanced_accuracy',cv=inner,
                                n_jobs=1,error_score='raise')
            nested.fit(x[train],y[train])
            pred=nested.predict(x[valid])
            nested_rows.append(dict(model=name,fold=fold+1,
                balanced_accuracy=balanced_accuracy_score(y[valid],pred),
                accuracy=accuracy_score(y[valid],pred),
                macro_f1=f1_score(y[valid],pred,average='macro'),
                selected_params=str(nested.best_params_)))
        scores=[r['balanced_accuracy'] for r in nested_rows if r['model']==name]
        row['nested_cv_balanced_accuracy']=float(np.mean(scores))
        row['nested_cv_sd']=float(np.std(scores))
        summaries.append(row); fitted[name]=search.best_estimator_
        if slug=='logistic':
            fig,ax=plt.subplots(figsize=(6.8,4))
            for intercept in [True,False]:
                f=frame[frame['param_model__fit_intercept']==intercept].sort_values('param_model__C')
                ax.errorbar(f['param_model__C'].astype(float),f['mean_test_balanced_accuracy'],
                    yerr=f['std_test_balanced_accuracy'],marker='o',capsize=3,label=f'Intercept={intercept}')
            ax.set(xscale='log',xlabel='C (inverse regularization)',ylabel='Mean CV balanced accuracy',
                   title='Logistic regression: five-fold CV ± fold SD'); ax.legend(); ax.grid(alpha=.2)
            fig.tight_layout(); savefig(out,'logistic_tuning')
        else:
            f=frame.copy(); f['gamma_label']=f['param_model__gamma'].astype(str)
            order=['0.0001','0.001','0.01','0.1','1','scale']
            table=f.pivot(index='param_model__C',columns='gamma_label',values='mean_test_balanced_accuracy').reindex(columns=order)
            fig,ax=plt.subplots(figsize=(8,4))
            im=ax.imshow(table.to_numpy(),vmin=.5,vmax=1,cmap='YlGnBu',aspect='auto')
            ax.set_xticks(range(len(order)),order); ax.set_yticks(range(len(table)),table.index)
            ax.set(xlabel='RBF gamma',ylabel='C',title='RBF SVM: mean five-fold CV balanced accuracy')
            for i in range(len(table)):
                for j in range(len(order)):
                    v=table.iloc[i,j]; ax.text(j,i,f'{v:.2f}',ha='center',va='center',color='white' if v>.85 else 'black')
            fig.colorbar(im,ax=ax); fig.tight_layout(); savefig(out,'svm_tuning')
        print(name, row,flush=True)
    pd.DataFrame(nested_rows).to_csv(out/'nested_cv_results.csv',index=False)
    # Python's stable max gives the first (linear) model on an exact tie.
    selected=max(summaries,key=lambda r:r['cv_balanced_accuracy'])['model']
    locked=dict(selected_model=selected,models=summaries,seed=SEED,
                rule='Highest mean 5-fold training CV balanced accuracy; exact model tie favors logistic regression.')
    (out/'selection_locked_before_test.json').write_text(json.dumps(locked,indent=2))
    return fitted,locked


def wilson_interval(correct,n,z=1.959963984540054):
    p=correct/n; den=1+z*z/n
    center=(p+z*z/(2*n))/den
    radius=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [float(center-radius),float(center+radius)]


def evaluate_locked_models(models,images,y,out):
    """Test metrics are descriptive; do not feed them back into model selection."""
    assert images.shape==(1000,28,28) and y.shape==(1000,)
    assert set(np.unique(y))=={1,7} and np.isfinite(images).all()
    x=images.reshape(len(images),-1); rows=[]; predictions={}
    fig,axes=plt.subplots(1,2,figsize=(8.5,3.7))
    for ax,(name,model) in zip(axes,models.items()):
        pred=model.predict(x); score=model.decision_function(x); predictions[name]=pred
        cm=confusion_matrix(y,pred,labels=[1,7])
        rows.append(dict(model=name,accuracy=float(accuracy_score(y,pred)),
            balanced_accuracy=float(balanced_accuracy_score(y,pred)),
            precision_7=float(precision_score(y,pred,pos_label=7,zero_division=0)),
            recall_7=float(recall_score(y,pred,pos_label=7,zero_division=0)),
            f1_7=float(f1_score(y,pred,pos_label=7)),
            macro_f1=float(f1_score(y,pred,average='macro')),
            roc_auc=float(roc_auc_score(y==7,score)),confusion_matrix=cm.tolist(),
            errors=int((pred!=y).sum()),accuracy_wilson_95=wilson_interval(int((pred==y).sum()),len(y))))
        ConfusionMatrixDisplay(cm,display_labels=[1,7]).plot(ax=ax,colorbar=False,cmap='Blues')
        ax.set_title(name)
    fig.suptitle('Locked models: final test evaluation (rows=true, columns=predicted)')
    fig.tight_layout(); savefig(out,'test_confusion_matrices')
    df=pd.DataFrame({'index':np.arange(len(y)),'true_digit':y})
    for name,pred in predictions.items(): df[name]=pred
    df.to_csv(out/'test_predictions.csv',index=False)
    pd.DataFrame(rows).to_csv(out/'test_metrics.csv',index=False)
    return rows,predictions


def cluster_grid(images,labels,centers,out,name,title,nearest=None):
    k=len(centers); cols=min(10,k); rows=int(np.ceil(k/cols))
    fig,axes=plt.subplots(rows,cols,figsize=(max(4,cols*1.15),rows*1.45),squeeze=False)
    for ax in axes.flat: ax.axis('off')
    for c,ax in enumerate(axes.flat):
        if c>=k: break
        pic=centers[c].reshape(28,28) if nearest is None else images[nearest[c]]
        ax.imshow(pic,cmap='gray',vmin=0,vmax=1)
        ax.set_title(f'C{c} | n={(labels==c).sum()}',fontsize=8)
    fig.suptitle(title,fontsize=11); fig.tight_layout(); savefig(out,name)


def cluster_digit_sevens(test_images,test_y,out):
    """Task 4 is post-hoc unsupervised analysis, isolated from classification.

    Analyze original normalized 784-D pixels. PCA is used ONLY for plotting.
    Search k in 2..30,40,50,...,90,99; largest mean silhouette wins (tie: k smaller).
    Selection has no claim of a universal, ground-truth number of handwriting styles.
    """
    images=scale_pixels(test_images[test_y==7]); x=images.reshape(len(images),-1)
    assert len(x)>=100, 'Required 100-cluster analysis needs at least 100 digit-7 images.'
    initial=KMeans(n_clusters=100,random_state=SEED,n_init=20,algorithm='lloyd').fit(x)
    cluster_grid(images,initial.labels_,initial.cluster_centers_,out,'centers_100',
                 'Required initial K-means: 100 digit-7 cluster centers')
    rows=[]; fits={}
    for k in CANDIDATE_K:
        if k>=len(x): continue
        km=KMeans(n_clusters=k,random_state=SEED,n_init=20,algorithm='lloyd').fit(x)
        sil=silhouette_score(x,km.labels_)
        rows.append(dict(k=k,inertia=float(km.inertia_),silhouette=float(sil),
            davies_bouldin=float(davies_bouldin_score(x,km.labels_)),
            smallest_cluster=int(np.bincount(km.labels_).min()),
            largest_cluster=int(np.bincount(km.labels_).max())))
        fits[k]=km
    frame=pd.DataFrame(rows); frame.to_csv(out/'clustering_candidates.csv',index=False)
    best=min(rows,key=lambda r:(-r['silhouette'],r['k'])); k=best['k']; km=fits[k]
    # Assess seed sensitivity after the predeclared silhouette selection.
    stability=[]
    for seed in [0,1,2,3,4]:
        other=KMeans(n_clusters=k,random_state=seed,n_init=20).fit(x)
        stability.append(dict(seed=seed,adjusted_rand_vs_selected=float(adjusted_rand_score(km.labels_,other.labels_)),
            silhouette=float(silhouette_score(x,other.labels_))))
    pd.DataFrame(stability).to_csv(out/'cluster_seed_stability.csv',index=False)
    fig,axes=plt.subplots(1,3,figsize=(12,3.7))
    for ax,col,lab in zip(axes,['inertia','silhouette','davies_bouldin'],
                          ['Within-cluster SSE (lower)','Mean silhouette (higher)','Davies–Bouldin (lower)']):
        ax.plot(frame.k,frame[col],marker='.',ms=4)
        ax.axvline(k,color='red',linestyle='--',label=f'Selected k={k}')
        ax.set(xlabel='Number of clusters k',ylabel=lab); ax.legend(fontsize=8); ax.grid(alpha=.2)
    fig.suptitle('Digit-7 clustering: fixed candidate search; silhouette selects k')
    fig.tight_layout(); savefig(out,'cluster_selection')
    nearest=[]; summaries=[]
    rr,cc=np.indices((28,28))
    original_indices=np.flatnonzero(test_y==7)
    for c in range(k):
        inds=np.flatnonzero(km.labels_==c)
        d=((x[inds]-km.cluster_centers_[c])**2).sum(axis=1)
        idx=inds[np.argmin(d)]; nearest.append(int(idx))
        center=km.cluster_centers_[c].reshape(28,28); mass=center.sum()
        top=center[:12]; bottom=center[16:]
        top_x=float((top*cc[:12]).sum()/top.sum()); bottom_x=float((bottom*cc[16:]).sum()/bottom.sum())
        summaries.append(dict(cluster=c,n=len(inds),percent=100*len(inds)/len(x),
            nearest_test_index=int(original_indices[idx]),mean_intensity=float(center.mean()),
            center_of_mass_x=float((center*cc).sum()/mass),center_of_mass_y=float((center*rr).sum()/mass),
            top_minus_bottom_x=top_x-bottom_x,
            mean_squared_distance=float(d.mean())))
    pd.DataFrame(summaries).to_csv(out/'selected_cluster_profiles.csv',index=False)
    pd.DataFrame({'test_index':original_indices,'cluster':km.labels_}).to_csv(out/'cluster_assignments.csv',index=False)
    np.savez_compressed(out/'cluster_centers.npz',initial_100=initial.cluster_centers_.reshape(100,28,28),
                       selected=km.cluster_centers_.reshape(k,28,28))
    cluster_grid(images,km.labels_,km.cluster_centers_,out,'selected_centers',f'Selected k={k}: mean digit-7 images')
    cluster_grid(images,km.labels_,km.cluster_centers_,out,'selected_representatives',
                 f'Selected k={k}: nearest actual image within each cluster',nearest=nearest)
    # Per-cluster samples avoid presenting a mean image as an actual example.
    fig,axes=plt.subplots(k,7,figsize=(11,max(3,k*2+.7)),squeeze=False)
    for c in range(k):
        inds=np.flatnonzero(km.labels_==c)
        dist=((x[inds]-km.cluster_centers_[c])**2).sum(axis=1)
        order=inds[np.argsort(dist)]
        pics=[km.cluster_centers_[c].reshape(28,28)]+[images[i] for i in order[:6]]
        for j,ax in enumerate(axes[c]):
            ax.axis('off')
            if j<len(pics):
                ax.imshow(pics[j],cmap='gray',vmin=0,vmax=1)
                ax.set_title(f'C{c} mean, n={len(inds)}' if j==0 else f'Test {original_indices[order[j-1]]}',fontsize=8)
    fig.suptitle('Each selected cluster: centroid followed by six closest members')
    fig.tight_layout(); savefig(out,'cluster_members')
    pca=PCA(n_components=2,random_state=SEED)
    z=pca.fit_transform(x)
    fig,ax=plt.subplots(figsize=(7,4.5))
    scatter=ax.scatter(z[:,0],z[:,1],c=km.labels_,s=13,cmap='tab10',alpha=.65)
    center_z=pca.transform(km.cluster_centers_)
    ax.scatter(center_z[:,0],center_z[:,1],marker='X',c='black',s=80)
    for c,pos in enumerate(center_z): ax.annotate(str(c),pos,xytext=(4,5),textcoords='offset points')
    ax.set(xlabel=f'PC1 ({pca.explained_variance_ratio_[0]:.1%} variance)',
           ylabel=f'PC2 ({pca.explained_variance_ratio_[1]:.1%} variance)',
           title='Digit-7 clusters projected to 2D (clustering uses all 784 pixels)')
    fig.colorbar(scatter,ax=ax,label='Cluster ID'); fig.tight_layout(); savefig(out,'cluster_pca')
    print('Clustering selected:',best,'n=',len(x),flush=True)
    return dict(n_sevens=len(x),initial_100_inertia=float(initial.inertia_),
        initial_100_silhouette=float(silhouette_score(x,initial.labels_)),
        initial_100_singletons=int((np.bincount(initial.labels_)==1).sum()),
        selected=best,profiles=summaries,seed_stability=stability,
        pca_explained_variance=pca.explained_variance_ratio_.tolist(),
        candidate_k=CANDIDATE_K)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--out',type=Path,default=Path('outputs'))
    args=parser.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    with threadpool_limits(limits=2):
        with np.load(args.data,allow_pickle=False) as data:
            assert set(data.files)=={'train_data','train_targets','test_data','test_targets'}
            # NPZ arrays are lazy: test_data/targets are not read until selection finishes.
            train=data['train_data']; y=data['train_targets']
            x,stats=inspect_training(train,y,args.out)
            models,selection=classifier_search(x,y,args.out)
            test=data['test_data']; test_y=data['test_targets']
            test_metrics,predictions=evaluate_locked_models(models,test,test_y,args.out)
            chosen=selection['selected_model']
            mistakes=np.flatnonzero(predictions[chosen]!=test_y)
            if len(mistakes):
                count=min(10,len(mistakes)); cols=min(5,count)
                fig,axes=plt.subplots(int(np.ceil(count/cols)),cols,figsize=(9,5),squeeze=False)
                for ax in axes.flat: ax.axis('off')
                for ax,idx in zip(axes.flat,mistakes[:10]):
                    ax.imshow(test[idx],cmap='gray',vmin=0,vmax=255); ax.axis('off')
                    ax.set_title(f'Test {idx}\nTrue {test_y[idx]}, pred {predictions[chosen][idx]}',fontsize=8)
                fig.suptitle(f'First {min(10,len(mistakes))} errors of training-CV-selected model ({chosen})')
                fig.tight_layout(); savefig(args.out,'test_errors')
            clusters=cluster_digit_sevens(test,test_y,args.out)
            # Data audit occurs after selection and is never a tuning input.
            train_set={a.tobytes() for a in train}
            overlap=sum(a.tobytes() in train_set for a in test)
            result=dict(seed=SEED,dataset_sha256=hashlib.sha256(args.data.read_bytes()).hexdigest(),
                versions={'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__,
                          'matplotlib':matplotlib.__version__},training=stats,selection=selection,
                test_counts={str(c):int((test_y==c).sum()) for c in [1,7]},test_metrics=test_metrics,
                exact_train_test_overlap=overlap,clustering=clusters)
            (args.out/'results.json').write_text(json.dumps(result,indent=2))
            print('Completed; selected classifier:',chosen,'test:',test_metrics,flush=True)


if __name__=='__main__':
    main()
